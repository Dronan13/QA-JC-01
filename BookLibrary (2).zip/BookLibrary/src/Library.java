import java.util.ArrayList;

public class Library{
	private ArrayList <Book> library = new ArrayList<>();

	public ArrayList<Book> getLibrary() {
		return library;
	}

	public void setLibrary(ArrayList<Book> library) {
		this.library = library;
	}
	
	public void addBook(String title,int pages,
			String author,String editor,
			int published){
		Book book = new Book();
		book.setBook(title, pages, author, editor, published);
		library.add(book);
	}
	public void addBook(Book book){
		library.add(book);
	}
	
	public void removeBook(int id){
		library.remove(id);
	}
		
	public void setTitle(int id, String title) {
		library.get(id).setTitle(title);
	}
	public void setPages(int id, int pages) {
		library.get(id).setPages(pages);
	}
	public void setAuthor(int id, String author) {
		library.get(id).setAuthor(author);
	}
	public void setEditor(int id, String editor) {
		library.get(id).setEditor(editor);
	}
	public void setPublished(int id, int published) {
		library.get(id).setPublished(published);
	}
	
	public void printLibrary(){
		for (Book book : library) {
	        System.out.println(
	        		book.getTitle()+" "+
	        		book.getAuthor()+" "+
	        		book.getPages()
	        		);
	    }
	}
	
	public void searchAuthor(String author){
		for (Book book : library) {
			if(book.getAuthor().contains(author))
		        System.out.println(
		        		book.getTitle()+" "+
		        		book.getAuthor()+" "+
		        		book.getPages()
		        		);
	    }
	}
	
	public void changeTitle (String title, String newtitle){
		int count = 0;
		for (Book book : library){
			if (book.getTitle().equals(title)){
				book.setTitle(newtitle);
				library.add(count, book);
			}
			count ++;
		}
	}
}
