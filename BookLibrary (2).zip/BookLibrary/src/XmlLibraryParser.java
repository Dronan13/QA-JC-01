import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

public class XmlLibraryParser {
	public static Document getDocument(String docName) throws Exception {
    	try {
            DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
            f.setValidating(false);         
            DocumentBuilder builder = f.newDocumentBuilder();
            return builder.parse(new File(docName));
        }catch (Exception exception) {
            String message = "XML parsing error!";
            throw new Exception(message);
        }
    } 
	
	public static void showBooks(Document doc){
		NodeList nList = doc.getElementsByTagName("book");
        for (int temp = 0; temp < nList.getLength(); temp++) {
           Node nNode = nList.item(temp);
           System.out.println("--------------------------");
           if (nNode.getNodeType() == Node.ELEMENT_NODE) {
              Element eElement = (Element) nNode;
              System.out.println("Book title : " + eElement.getAttribute("title"));
              System.out.println("Book pages : " + eElement.getAttribute("pages"));
              System.out.println("Author : " 
                 + eElement.getElementsByTagName("author").item(0)
                 .getTextContent());
              System.out.println("Editor : " 
            		  + eElement.getElementsByTagName("editor").item(0)
            		  	.getTextContent());
              System.out.println("Published : " 
              + eElement
                 .getElementsByTagName("published").item(0)
                 	.getTextContent());
           }
        }        
    }
	public static void booksToLibrary(Document doc, Library lib){
		NodeList nList = doc.getElementsByTagName("book");
        for (int temp = 0; temp < nList.getLength(); temp++) {
           Node nNode = nList.item(temp);
           if (nNode.getNodeType() == Node.ELEMENT_NODE) {
        	  Book book = new Book();
              Element eElement = (Element) nNode;
              book.setBook(eElement.getAttribute("title"), 
	            		  	Integer.parseInt(eElement.getAttribute("pages")), 
	            		  	eElement.getElementsByTagName("author")
	            		  	.item(0).getTextContent(), 
	                   		eElement.getElementsByTagName("editor")
	                   		.item(0).getTextContent(), 
	                   		Integer.parseInt(eElement.getElementsByTagName("published")
	                   		.item(0).getTextContent()));
              lib.addBook(book);
           }
        }        
    }
	
	public static void libraryToXml(Library lib, String filepath) throws Exception{

		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.newDocument();
		Element rootElement = doc.createElement("library");
		doc.appendChild(rootElement);
		
		for(Book book : lib.getLibrary()){
	        Element rbook = doc.createElement("book");
	        rootElement.appendChild(rbook);
	        rbook.setAttribute("title", book.getTitle());
	        rbook.setAttribute("pages", String.valueOf(book.getPages()));
	        
	        Element author = doc.createElement("author");
	        author.appendChild(doc.createTextNode(book.getAuthor()));
	        rbook.appendChild(author);

	        Element editor = doc.createElement("editor");
	        editor.appendChild(doc.createTextNode(book.getEditor()));
	        rbook.appendChild(editor);
            
	        Element published = doc.createElement("published");
	        published.appendChild(doc.createTextNode(
	        		String.valueOf(book.getPublished())));
	        rbook.appendChild(published);
		}
		TransformerFactory transformerFactory = 
				TransformerFactory.newInstance();
        Transformer transformer = 
        		transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(
        		new File(filepath));
        transformer.transform(source, result);
        System.out.println("File saved!");
	}
}
