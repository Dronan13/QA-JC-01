
public class Main {

	public static void main(String[] args) throws Exception{
		//Library lib = new Library();	
		//lib.addBook("title0", 0, "author0", "editor0", 2016);
		//lib.addBook("title1", 0, "author1", "editor1", 2017);
		//lib.addBook("title2", 0, "author2", "editor2", 2018);
		//lib.addBook("title3", 0, "author3", "editor3", 2019);
		//lib.setAuthor(0, "new author0");
		//lib.setTitle(2, "new book title");
		//lib.printLibrary();
		//lib.searchAuthor("author1");
		//XmlLibraryParser.libraryToXml(lib, "library2.xml");
		//XmlLibraryParser.showBooks(XmlLibraryParser.getDocument("library.xml"));
		/*XmlLibraryParser.booksToLibrary(
				XmlLibraryParser.getDocument("library.xml"), 
				lib);
		lib.printLibrary();
		*/
		Book kaknibud= new Book();
		kaknibud.setBook("titanik/1000/cameron/columbiapichers/1997");
		System.out.println(kaknibud.getTitle());
	}

}
